﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GK_Pharma
{
    public partial class adminLoginPage : Form
    {
        Form1 mainform;
        public adminLoginPage(Form1 main)
        {
            InitializeComponent();
            mainform = main;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                errorlabel.Text = "fill all the required fields";
            }
            else
            {
                string connetionString = null;
                OleDbConnection connection;
                OleDbDataAdapter oledbAdapter = new OleDbDataAdapter();
                DataSet ds = new DataSet();
                connetionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=E:\\pharmacy.accdb";
                connection = new OleDbConnection(connetionString);
                try
                {
                    connection.Open();
                    oledbAdapter.SelectCommand = new OleDbCommand("select * from useraccount where emailid = '" + username + "' and password = '" + password + "' and role = 'admin'", connection);
                    oledbAdapter.Fill(ds);
                    oledbAdapter.Dispose();
                    connection.Close();
                    if (ds.Tables[0].Rows.Count == 0)
                    {
                        errorlabel.Text = "* Invalid Username/password";
                    }
                    else
                    {

                        MainPage nextForm = new MainPage();
                        mainform.Hide();
                        nextForm.ShowDialog();
                        mainform.Close();




                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }
    }
}
