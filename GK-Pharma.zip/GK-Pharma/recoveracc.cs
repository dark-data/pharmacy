﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GK_Pharma
{
    public partial class recoveracc : Form
    {
        public recoveracc()
        {
            InitializeComponent();
        }

        private void errorlabel_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string emailip = textBox1.Text;
            if (string.IsNullOrWhiteSpace(emailip))
            {
                errorlabel.Text = "* recovery email field cant be empty";
            }else{
                string connetionString = null;
                OleDbConnection connection;
                OleDbDataAdapter oledbAdapter = new OleDbDataAdapter();
                DataSet ds = new DataSet();
                connetionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=E:\\pharmacy.accdb";
                connection = new OleDbConnection(connetionString);
                try
                {
                    connection.Open();
                    oledbAdapter.SelectCommand = new OleDbCommand("select * from useraccount where emailid = '"+emailip+"'", connection);
                    oledbAdapter.Fill(ds);
                    oledbAdapter.Dispose();
                    connection.Close();
                    string userpassword = "";
                    if (ds.Tables[0].Rows.Count == 0)
                    {
                        userpassword = "";
                    }
                    else
                    {
                        userpassword = ds.Tables[0].Rows[0].ItemArray[2].ToString();
                    }
                    
                    
                    if (string.IsNullOrWhiteSpace(userpassword))
                    {
                        errorlabel.Text = "* recovery email did not match with any account";
                    }
                    else
                    {
                        emailAction ea = new emailAction(emailip, userpassword);
                        MessageBox.Show("email has been sent  successfully");
                        errorlabel.Text = "*Password has been sent";
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }
    }
}
