﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GK_Pharma
{
    public partial class Form1 : Form
    {
        private Form CurrentChildForm;
        //to drag form
        private bool dragging = false;
        private Point startPoint = new Point(0, 0);

        public Form1()
        {
            InitializeComponent();
        }

        private void iconButton7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void iconButton6_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox2.BringToFront();
            if (CurrentChildForm != null)
            {
                CurrentChildForm.Close();
            }
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            OpenChildForm(new recoveracc());
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            OpenChildForm(new loginpage(this));
        }

        //rj code for form within panel
        private void OpenChildForm(Form ChildForm)
        {
            if(CurrentChildForm != null)
            {
                CurrentChildForm.Close();
            }
            CurrentChildForm = ChildForm;
            CurrentChildForm.TopLevel = false;
            CurrentChildForm.FormBorderStyle = FormBorderStyle.None;
            CurrentChildForm.Dock = DockStyle.Fill;
            panel2.Controls.Add(CurrentChildForm);
            panel2.Tag = CurrentChildForm;
            CurrentChildForm.BringToFront();
            CurrentChildForm.Show();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            startPoint = new Point(e.X, e.Y);
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X-this.startPoint.X, p.Y-this.startPoint.Y);
            }
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            OpenChildForm(new adminLoginPage(this));
        }
    }
}
